<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use App\Model\Client\clientProfile as cProfile;
use App\Model\Client\addBranch as cBranch;
use Illuminate\Http\Request;
use Validator;
use Session;
use Redirect;
use File;

class clientProfile extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	 public function __construct()
{
    $this->middleware('auth');
}
     public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
	  return view('ClientAdmin.branch.add'); 
    }
	
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * Set up client Profile 
     */
	 
     public function store(Request $request)
    {
	
	   $input = $request->all();
	   $validator = Validator::make($input, [
				'company_name' => 'required',
				//'tagline' => 'required',
				'company_name' => 'required',
				'address' => 'required',
				'business_email' => 'required|email',
				'phone_number' => 'required|numeric|digits_between:6,10'
				]);
					
					
	  if ($validator -> fails()) {
		return redirect() -> back() -> withInput($input) -> withErrors($validator -> errors());
	}   
	   
	
	
	
		try{
			$data = array_except($request->all(),['_token']);
			// Get the currently authenticated user's ID...
			$data['client_id']=Auth::id();
			$dataCount =cProfile::where('client_id',Auth::id())->count();
			$dataGet =cProfile::where('client_id',Auth::id())->first();
		 	$dataGet['company_logo'];
			//image secure and update
			if ($request->hasFile('company_logo')){
				$image = $request->file('company_logo');
				$name = time().'.'.$image->getClientOriginalExtension();
				$destinationPath = public_path('/ClientImages');
				$image->move($destinationPath, $name);
				$data['company_logo'] =$name;
			if(!empty($dataGet['company_logo'])){
			unlink(public_path('/ClientImages/'.$dataGet['company_logo']));//remove old saved images 
			}
			}
			else{
				$data['company_logo']=$dataGet['company_logo'];
			}

			if($dataCount){
				echo 'update'.$result =cProfile::where('client_id',Auth::id())->update($data);
				return redirect('/home')->with('success','Client Profile Updated Successfully');
			}
			else{
				$dataCount =cProfile::where('client_id',Auth::id())->count();
				$result =cProfile::insert($data);
				return redirect('/home')->with('success','Client Profile Submit Successfully');
			}
		}
		catch(\Exception $e){
			// return exception
			return redirect('/home')->with('error',$e->getMessage());
		}	
   }

    /**
     * Display the specified resource.
     *
     * @param  \App\client  $client
     * @return \Illuminate\Http\Response
     */
    public function show(client $client)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\client  $client
     * @return \Illuminate\Http\Response
     */
    public function edit(client $client)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\client  $client
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, client $client)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\client  $client
     * @return \Illuminate\Http\Response
     */
    public function destroy(client $client)
    {
        //
    }
	
	public function we_create(){
	$length = 10;
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return strtoupper($randomString);
		
		
		}
}
