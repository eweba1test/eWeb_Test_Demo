<?php
class myUser extends sfBasicSecurityUser
{
	public function signIn($loginName)
	{
		if(sfConfig::get('sf_logging_enabled'))
		{
		 	sfContext::getInstance()->getLogger()->info("Inside my user class sign in." . $loginName);
		}
		$this->setAuthenticated(true);
		$this->addCredential('userinformation');
		$this->setAttribute('loginname',$loginName, 'userinformation');
		$this->addCredential('userstats');
		$this->getUserDetails();
		//$this->updateUserIdentifier();
	}
	public function getUserDetails()
	{
		$username=$this->getLoginName();
		$dbCon=OCILogon(sfConfig::get('app_oracle_UserName'),sfConfig::get('app_oracle_Password'),sfConfig::get('app_oracle_Server'));
		if (!$dbCon) 
		{
	   		echo "Unable to connect: " . var_dump( OCIError() );
	   		if(sfConfig::get('sf_logging_enabled'))
			{
			 	sfContext::getInstance()->getLogger()->info("Unable to connect: " . var_dump( OCIError() ));
			}
			die();
		}
		
		if(sfConfig::get('sf_logging_enabled'))
		{
		 	sfContext::getInstance()->getLogger()->info('Inside get user details.');
		}
		
		$cursorUserInfo = OCINewCursor($dbCon);
		$cursorMessages = OCINewCursor($dbCon);
		$cursorProgressReport = OCINewCursor($dbCon);
		$cursorUserLinks = OCINewCursor($dbCon);
		$sql = OCIParse($dbCon, "begin S_USER_INFO(:binUserName,:bndCursorUserInfo,:bindCursorMessages,:bindCursorProgressReport,:bindCursorUserLinks,:bindReturnCode,:bindStatus); end;");
		
		oci_bind_by_name($sql,":binUserName",$username);
		oci_bind_by_name($sql,":bndCursorUserInfo",$cursorUserInfo,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindCursorMessages",$cursorMessages,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindCursorProgressReport",$cursorProgressReport,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindCursorUserLinks",$cursorUserLinks,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindReturnCode",$returnCode,32);
		oci_bind_by_name($sql,":bindStatus",$status,255);
		$r=OCIExecute($sql);
		if (!r) 
  		{
			$err =oci_error($sql);
			utility::logInfo($err['message']);
			utility::logInfo('Cannot retrieve user info.'. $username . $returnCode);
			utility::logInfo('Cannot retrieve user info. Reason :' . $status);
   	 	}
	    ociexecute($cursorUserInfo) or die('Cannot execute cursor UserInfo'); 
	    ociexecute($cursorMessages) or die('Cannot execute cursor Messages'); 
	    ociexecute($cursorProgressReport) or die('Cannot execute cursor ProgressReport'); 
	    ociexecute($cursorUserLinks) or die('Cannot execute cursor UserLinks'); 
	    
	    if(number_format($returnCode)==1)
		{
			while (OCIFetchInto($cursorUserInfo,$user)) 
			{ 
				if(count($user)>0)
				{
					/*
					ar_Cursor1 of S_USER_INFO has the following structure:
				      first_name
				      last_name
				      days
				      days_left
				      starting_weight
				      target_weight
				      diet_text
				      diet_actual_start_date (for 'Starting Date' in 'My Stats')
				      bt_order_type (for the type of window to be displayed when clicking on 'Blood Test Order'. 'TESTER1' should return 1 , all others will return 2)
				      order_bt_ref (this is the BLOB, a PDF, needs to be displayed for 'Your Blood Test Referral' of ar_Cursor4)
                                  referral_ind (indicate cust was referred. Different link for Renewal)
                                  country_code (indicate different links for Payment Renewal)
					*/
			   		$this->setAttribute('membername', $user[0] . ' ' . $user[1], 'userinformation');
					$this->setAttribute('noOfDays', $user[2], 'userstats');
					$this->setAttribute('daysLeft', $user[3], 'userstats');
					$this->setAttribute('initialWeight', $user[4], 'userstats');
					$this->setAttribute('targetWeight', $user[5], 'userstats');
                                   $this->setAttribute('countryCode', $user[11], 'userstats');
					if($user[6]!=null)
					{
						$this->setAttribute('dietText',$user[6]->load(),'userstats');
					}
					else
					{
						$this->setAttribute('dietText','','userstats');
					}	
					$this->setAttribute('startingDate',$user[7],'userstats');
					$this->setAttribute('bloodTestOrderType',$user[8],'userstats');
                                   $this->setAttribute('programRenewalType',$user[10],'userstats');
					if(null!=$user[9])
					{
						$this->setAttribute('orderBloodTestRef',$user[9]->load(),'userstats');
						utility::logInfo('OrderBloodTestRef Found');
					}
					else
					{
						$this->setAttribute('orderBloodTestRef','','userstats');
						utility::logInfo('OrderBloodTestRef Not Found');
					}
				}
		   		
			}
			$arrMessages=null;
			while (OCIFetchInto($cursorMessages,$message)) 
			{
				$arrMessages[]=$message;
			}
			$this->setAttribute('usermessages',$arrMessages, 'userstats');
			
			$arrProgressReport=null;
			while(OCIFetchInto($cursorProgressReport,$report))
			{
				$arrProgressReport[]=$report;
				$report=null;
			}
			$this->setAttribute('userProgressReport',$arrProgressReport,'userStats');
			
			$arrUserLinks=null;
			while (ocifetchinto($cursorUserLinks,$userLink)) 
			{
				$arrUserLinks[]=$userLink;
				$userLink=null;
			}
			$this->setAttribute('userLinks',$arrUserLinks, 'userstats');
			
			$arrProgressReport=null;
			$arrMessages=null;
			$arrUserLinks=null;
			
			oci_free_cursor($cursorUserLinks);
			oci_free_cursor($cursorProgressReport);
			oci_free_cursor($cursorMessages);
			oci_free_cursor($cursorUserInfo);
			oci_close($dbCon);
			
			return true;
		}
		return false;
	}
	public function signOut()
	{
	  	$this->getAttributeHolder()->removeNamespace('userinformation');
	  	$this->getAttributeHolder()->removeNamespace('userstats');
	  	$this->setAuthenticated(false);
		$this->clearCredentials();
		sfContext::getInstance()->getResponse()->setCookie('user_SESSION', '', time() - 3600, '/');
	}
	public function getOrderBloodTestRef()
	{
		return $this->getAttribute('orderBloodTestRef','','userstats');
	}
	public function getUserBloodTestOrderType()
	{
		return $this->getAttribute('bloodTestOrderType','','userstats');
	}
	public function getProgramRenewalType()
	{
		return $this->getAttribute('programRenewalType','','userstats');
	}
	public function getUserCountryCode()
	{
		return $this->getAttribute('countryCode','','userstats');
	}
	public function getUserStartingDate()
	{
		return $this->getAttribute('startingDate','','userstats');
	}
	public function getUserDietText()
	{
		return $this->getAttribute('dietText','','userstats');
	}
	public function getUserLinks()
	{
		return $this->getAttribute('userLinks','', 'userstats');
	}
	public function getUserMessages()
	{
		return $this->getAttribute('usermessages','', 'userstats');
	}
	public function getProgressReport()
	{
		return $this->getAttribute('userProgressReport','', 'userStats');
	}
	public function getLoginName()
	{
		return $this->getAttribute('loginname','', 'userinformation');
	}
	public function getMemberName()
	{
	  return $this->getAttribute('membername', '', 'userinformation');
	}
	public function getNoOfDays()
	{
		return $this->getAttribute('noOfDays', '', 'userstats');
	}
	public function getDaysLeft()
	{
		return $this->getAttribute('daysLeft', '', 'userstats');
	}
	public function getInitialWeight()
	{
		return $this->getAttribute('initialWeight', '', 'userstats');
	}
	public function getTargetWeight()
	{
		return $this->getAttribute('targetWeight', '', 'userstats');
	}
	
	public function passwordChanged($rowAffected)
	{
		$this->setAttribute('passwordChanged', $rowAffected, 'userinformation');		
	}
	public function isPasswordChanged()
	{
		return $this->getAttribute('passwordChanged','','userinformation');
	}
}
