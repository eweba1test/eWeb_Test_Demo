	Route::get('client-change_password', 'HomeController@changeclientPassword');
	Route::any('new-change-password','HomeController@NewChangePassword');
	Route::resource('client','clientProfile'); 