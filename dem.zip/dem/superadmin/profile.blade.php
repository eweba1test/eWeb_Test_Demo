@extends('layouts.ClientAdmin.main')
@section('page-content')
<style>
.img-thumbnail{
  width:100%;
  height:100px;
  object-fit: cover;
  object-position: center;
  margin:10px;
}

@media(max-width: 480px) {
  .img-thumbnail{
    height:50px;
  }
}
input#company_name::placeholder {
    color: #777 !important;
}

</style>
<!-- Content Wrapper. Contains page content https://jsfiddle.net/Logan_Wayne/xz6dgLz1/                  -->
  <div class="content-wrapper profile-page change-pass">
    <!-- Content Header (Page header) -->
    <section class="content-header">
	 <div class="row header-change">
      <h4>
       Profile 
      </h4></div>
	   @if(Session::has('success')) 
				<div id="successMessage"  class="alert alert-success"><center> {{Session::get('success')}} </center>
				</div>
			@endif
			@if(Session::has('error'))
			 <div id="errorMessage"  class="alert alert-danger"><center> 
				{{Session::get('error')}} </center>
			 </div>
		@endif
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
	  
      <!--------------------------
        | Your Page Content Here |
        -------------------------->
@if ($errors->any())
			
							<div class="abs hide"  >
								<ul>
									@foreach ($errors->all() as $error)
										<li style="color:red;">{{ $error }}</li>
									@endforeach
								</ul>
							</div>
	@endif
<form id="form-change-password" role="form" method="POST" enctype="multipart/form-data" action="{{ route('client.store') }}" novalidate class="form-horizontal">
  <div class="left-side-prof">             
    <label for="current-password" class="col-sm-12 control-label">Name of the company</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
         <input type="hidden" name="client_id" value="@if(!empty($client_profile['client_id'])){{$client_profile['client_id']}} @endif" >   <!--  insert id input-->
        <input type="text" value="@if(!empty($client_profile['company_name'])){{$client_profile['company_name']}} @else {{old('company_name')}} @endif" class="form-control" id="company_name" name="company_name" placeholder="Company name" required>
      </div>
    </div>
<!-- Upload multiple image  start -->
    <label for="logo" class="col-sm-12 control-label">Upload Company logo</label>
   <div class="col-sm-12 col-md-12 logo-img"><input  type="file" class="col-sm-12 p-0 m-0" name="company_logo"  accept=".png, .jpg, .jpeg"  id="profile-img">
   @if(!empty($client_profile['company_logo']))
   
	<img   id="profile-img-tag" width="100" height="80" src="{{url('/public/ClientImages/'.$client_profile['company_logo'])}}">
    @endif </div>
<div id="status"></div>
  <div id="photos" class="row"></div>
  
  
<!-- Upload multiple image  end -->
  
    
 
  
   <label for="tagline" class="col-sm-12 control-label">Tagline (if any)</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input value="@if(!empty($client_profile['tagline'])){{$client_profile['tagline']}} @else {{old('tagline')}} @endif" type="text" class="form-control" id="tagline" name="tagline" placeholder="Tagline" required>
      </div>
    </div>  
	</div>
	<div class="right-side-prof"> 
	<label for="phone_number" class="col-sm-4 control-label">Phone Number</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input value="@if(!empty($client_profile['phone_number'])){{$client_profile['phone_number']}} @else {{old('phone_number')}}  @endif" type="text" class="form-control" id="phone_number" name="phone_number" placeholder="Phone number" required>
      </div>
    </div>
	
  <label for="Address" class="col-sm-12 control-label">Address of the place</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input value="@if(!empty($client_profile['address'])){{$client_profile['address']}} @else {{old('address')}} @endif" type="text" class="form-control" id="address" name="address" placeholder="Address" required>
      </div>
    </div>
	<label for="email" class="col-sm-4 control-label">Business email</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input value="@if(!empty($client_profile['business_email'])){{$client_profile['business_email']}}  @else {{old('business_email')}} @endif" type="email" class="form-control" id="business_email" name="business_email"  required>
      </div>
    </div>
	
    <div class="form-group">
    <div class="col-sm-offset-5 col-sm-6">
      <button type="submit" class="btn btn-danger profile-btn">Submit</button>
    </div>
  </div>
  </div>
</form>

	 	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<!-- Upload multiple image  start -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>


    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img").change(function(){
        readURL(this);
    });

	 // function readFile(input) {
		//alert('cdccdd');
  	// $("#status").html('Processing...');
     // counter = input.files.length;
		// for(x = 0; x<1; x++){
			// if (input.files) {

				 // var reader = new FileReader();

				 // reader.onload = function (e) {
        	// $("#photos").append('<div class="col-md-3 col-sm-3 col-xs-3"><img src="'+e.target.result+'" class="img-thumbnail"></div>');
				 // };

			 // reader.readAsDataURL(input.files[x]);
			 // }
     // }
    // if(counter == 1){$("#status").html('');}
  // }
  
  $('.abs').slideUp(5000);
</script>
<!-- Upload multiple image  end -->
@endsection
