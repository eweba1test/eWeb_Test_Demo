<?php
// Create connection to Oracle
$dbCon = oci_connect('toracle02', 'noPI4you', 'af3-l.appsforte.com:1601/ttci.appsforte.com');
if (!$dbCon) {
   $m = oci_error();
   echo $m['message'], "\n";
   exit;
}
else {
   print 'Connected to Oracle!';   echo "<br>";
   $username= 'TESTER1';
        $cursorUserInfo = OCINewCursor($dbCon);
		$cursorMessages = OCINewCursor($dbCon);
		$cursorProgressReport = OCINewCursor($dbCon);
		$cursorUserLinks = OCINewCursor($dbCon);
		$sql = OCIParse($dbCon, "begin S_USER_INFO(:binUserName,:bndCursorUserInfo,:bindCursorMessages,:bindCursorProgressReport,:bindCursorUserLinks,:bindReturnCode,:bindStatus); end;");
		
		oci_bind_by_name($sql,":binUserName",$username);
		oci_bind_by_name($sql,":bndCursorUserInfo",$cursorUserInfo,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindCursorMessages",$cursorMessages,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindCursorProgressReport",$cursorProgressReport,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindCursorUserLinks",$cursorUserLinks,-1,OCI_B_CURSOR);
		oci_bind_by_name($sql,":bindReturnCode",$returnCode,32);
		oci_bind_by_name($sql,":bindStatus",$status,255);
		$r=OCIExecute($sql);
		ociexecute($cursorUserInfo) or die('Cannot execute cursor UserInfo'); 
	    ociexecute($cursorMessages) or die('Cannot execute cursor Messages'); 
	    ociexecute($cursorProgressReport) or die('Cannot execute cursor ProgressReport'); 
	    ociexecute($cursorUserLinks) or die('Cannot execute cursor UserLinks'); 
		while (OCIFetchInto($cursorUserInfo,$user)) 
			{ 
				if(count($user)>0)
				{
				print_r($user);
				}
			}
		//print_r($r);

/* Get the output on the screen */
}
// Close the Oracle connection
oci_close($dbCon);

?>
