Route::any('customer/edit-profile', 'CustomerController@Customerprofile');
Route::any('customer/profileUpdate/{id}', 'CustomerController@Profileupdate');
Route::any('customer/changepassword', 'CustomerController@changepassword');
Route::any('customer/NewChangeBranchPassword', 'CustomerController@NewChangeBranchPassword');