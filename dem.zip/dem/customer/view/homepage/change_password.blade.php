@extends('layouts.HomePage.Corporate.main')
@section('page-content')


<style>
.top-2 {
    position: relative;
    padding-top: 100px;
	margin-bottom: 50px;
}
</style>
<!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper change-pass">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      
    </section>

    <!-- Main content -->
    <section class="content container" >
      <!--------------------------
        | Your Page Content Here |
        -------------------------->
 <div class="col-md-12 col-md-offset-0 top-2">
		   @if (count($errors) > 0)
				<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert">&times;</a> 
					<strong>Oops!</strong> There is problems with your input.<br><br>
					<ul>
						@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
						@endforeach
					</ul>
				</div>
			@endif
			@if(session()->has('error'))
				<div class="alert alert-error">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					 {{ session()->get('error') }}
				</div>
			@endif
			@if(Session::has('flash_message'))
		    <div class="alert {{ Session::get('alert-class') }}">
			<a href="#" class="close" data-dismiss="alert">&times;</a> 
			{{Session::get('flash_message')}}
		    </div>
		@endif
		
	<h1 class="common-heading">
    Change Password </h1>
		
<form id="form-change-password" role="form" method="POST" action="{{ url('customer/NewChangeBranchPassword') }}" novalidate class="form-horizontal">
  <div class="left-side-prof">             
    <label for="current-password" class="col-sm-12 control-label">Current Password</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
        <input type="password" class="form-control" id="current-password" name="current-password" placeholder="Current Password" required>
      </div>
    </div>
    <label for="password" class="col-sm-12 control-label">New Password</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input type="password" class="form-control" id="password" name="password" placeholder="New Password" required>
      </div>
    </div>
    <label for="password_confirmation" class="col-sm-12 control-label">Re-enter Password</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Re-enter Password">
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-5 col-sm-6">
      <button type="submit" class="btn btn-danger">Submit</button>
    </div>
  </div>
</form>
	
		
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection
