     <li class="dropdown user_prof">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                              <i class="fa fa-user" aria-hidden="true"></i><span class="d-none d-md-inline-block">{{Auth::user()->name}}</span></a>
                              <ul class="dropdown-menu">
				
							  <li> <a class="nav-link dropdown-item" href="{{ url('customer/edit-profile') }}">Profile Edit</a></li>
							  <li ><a  class="nav-link dropdown-item" href="{{ url('customer/changepassword') }}">Change Password</a></li>
			                  <li >  
                                 <a class="dropdown-item nav-link nav-item  dropdown-item text-danger" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                         {{ __('Logout') }}
                                    </a>
									<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>		</li>	  
							  
            </ul>
          </li>
    

                             
								
							<?Php	}
								
								}else{
							
							  ?>
							  <li class="nav-item   {{ (isset($activeMenu) && $activeMenu =='plans')? 'active' :''  }}">
                                <a class="nav-link" href="{{url('/plans')}}">Plans</a>
                              </li>
							  <li class="nav-item1">
                                <a class="login-head" href="{{ route('login') }}">log in</a>
                              </li>
                             <!-- <li class="nav-item1">
                                <a class="signup-head" href="{{ url('sign-up') }}">customer sign up</a>
                              </li> -->
							  
							  <li class="nav-item1">
                                <a class="signup-head" href="{{ url('customer_sign_up') }}"> sign up</a>
                              </li>
								<?Php  } ?>