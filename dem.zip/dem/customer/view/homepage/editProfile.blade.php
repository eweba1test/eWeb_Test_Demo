@extends('layouts.HomePage.Corporate.main')
@section('page-content')
<style>
.img-thumbnail{
  width:100%;
  height:100px;
  object-fit: cover;
  object-position: center;
  margin:10px;
}

@media(max-width: 480px) {
  .img-thumbnail{
    height:50px;
  }
}

.top-2 {
    position: relative;
    padding-top: 100px;
	margin-bottom: 50px;
}
.header-change {
    padding-top: 140px;
}
.header-change h4 {
    text-indent: 31px;
}

</style>
<!-- Content Wrapper. Contains page content https://jsfiddle.net/Logan_Wayne/xz6dgLz1/                  -->
  <div class="content-wrapper profile-page change-pass">
    <!-- Content Header (Page header) -->
    <section class="content-header">
	 <div class="header-change">
   </div>
	   @if(Session::has('success')) 
				<div class="alert alert-success"><center> {{Session::get('success')}} </center>
				</div>
			@endif
			@if(Session::has('error'))
			 <div class="alert alert-danger"><center> 
				{{Session::get('error')}} </center>
			 </div>
		@endif
    </section>

    <!-- Main content -->
    <section class="content container">
	  
      <!--------------------------
        | Your Page Content Here |
        -------------------------->
		   @if (count($errors) > 0)
				<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert">&times;</a> 
					<strong>Whoops!</strong> There were some problems with your input.<br><br>
					<ul>
						@foreach ($errors->all() as $error)
						<li>{{ $error }}</li>
						@endforeach
					</ul>
				</div>
			@endif
			@if(session()->has('error'))
				<div class="alert alert-error">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
					 {{ session()->get('error') }}
				</div>
			@endif
			@if(Session::has('flash_message'))
		    <div class="alert {{ Session::get('alert-class') }}">
			<a href="#" class="close" data-dismiss="alert">&times;</a> 
			{{Session::get('flash_message')}}
		    </div>
		@endif
   
   <h1 class="common-heading">
    Profile </h1>
<form id="form-change-password" role="form" method="POST" enctype="multipart/form-data" action="{{URL('customer')}}/profileUpdate/{{$User->id}}" novalidate class="form-horizontal">
  <div class="left-side-prof">             
    <label for="current-password" class="col-sm-12 control-label">Name of the customer</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
 
        <input type="text" value="@if(!empty($User->name)){{$User->name}} @endif" class="form-control"  name="name" placeholder="Customer name" required>
      </div>
    </div>

<div id="status"></div>
  <div id="photos" class="row"></div>
  
  
<!-- Upload multiple image  end -->
  
   <div class="right-side-prof"> 
	<label for="phone_number" class="col-sm-4 control-label">Phone Number</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input value="@if(!empty($User->phone_number)){{$User->phone_number}} @endif" type="text" class="form-control" id="phone_number" name="phone_number" placeholder="Phone number" required>
      </div>
    </div>
	
  <label for="Address" class="col-sm-12 control-label">Address of the place</label>
    <div class="col-sm-12">
      <div class="form-group">
        <input value="@if(!empty($User->address)){{$User->address}} @endif" type="text" class="form-control" id="address" name="address" placeholder="Address" required>
      </div>
    </div>
   <label for="email" class="col-sm-4 control-label">Business email</label>
    <div class="col-sm-12">
      <div class="form-group">email
        <input value="@if(!empty($User->email)){{$User->email}} @endif" type="email" class="form-control"  name="email" placeholder="Email" readonly required>
      </div>
    </div>
	
    <div class="form-group">
    <div class="col-sm-offset-5 col-sm-6">
      <button type="submit" class="btn btn-danger profile-btn">Submit</button>
    </div>
  </div>
  </div>
</form>

	 	
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<!-- Upload multiple image  start -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
	function readFile(input) {
  	$("#status").html('Processing...');
    counter = input.files.length;
		for(x = 0; x<counter; x++){
			if (input.files && input.files[x]) {

				var reader = new FileReader();

				reader.onload = function (e) {
        	$("#photos").append('<div class="col-md-3 col-sm-3 col-xs-3"><img src="'+e.target.result+'" class="img-thumbnail"></div>');
				};

				reader.readAsDataURL(input.files[x]);
			}
    }
    if(counter == x){$("#status").html('');}
  }
</script>
<!-- Upload multiple image  end -->
@endsection
