<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Booking;
use Validator;
use DB;
use Session; 
use Hash;
use Redirect;
use App\Model\Client\clientProfile;

class CustomerController extends Controller
{
    public $successStatus = 200;
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
		
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
     public function Customerprofile(){
	    
		
	    $Customer_id = Auth::user()->id;	
	
		$User = user::where(['account_type'=>4,'id'=>$Customer_id,'status'=>1])->first();
		
	    return view('HomePage/editProfile')->with(compact('User'));
	
	}
	
	
	public function Profileupdate(Request $request, $id)
    {
		
	   $input = $request->all();
	   $messages = array(
		'name.required'=>'The user name field is required.',
		'address.required'=>'The address field is required.',
		'phone_number.required'=>'The phone number field is required.'
        
	    );

	    $validator = Validator::make($input, [
		'name' => 'required',
		'address' => 'required',
		'phone_number' => 'required|max:12|min:6'
		], $messages);
		
	  if ($validator -> fails()) {
		return redirect() -> back() -> withInput($input) -> withErrors($validator -> errors());
	}
	  
		
		DB::table('users')
            ->where('id', $id)
            ->update([	
            'name' => $request->input('name'),
            'address' => $request->input('address'),
			'phone_number' => $request->input('phone_number')
			
			]); 
	   
	
        Session::flash('flash_message', 'User update successfully');
        Session::flash('alert-class', 'alert-success');
        return redirect()->back();

    }
	
	public function admin_credential_rules(array $data)
	{
	  $messages = [
		'current-password.required' => 'Please enter current password',
		'password.required' => 'Please enter new password',
	  ];

	  $validator = Validator::make($data, [
		'current-password' => 'required',
		'password' => 'required|same:password',
		'password_confirmation' => 'required|same:password|min:6',     
	  ], $messages);

	  return $validator;
	}  
	
	
    public function changepassword(){
		//die('gfgfg');
		
		return view('HomePage.change_password');
	}	

   public function NewChangePassword(Request $request)
	{

	  if(Auth::Check())
	  {
		$request_data = $request->All();
		$validator = $this->admin_credential_rules($request_data);
		if($validator->fails())
		{
		   return Redirect::back()->withErrors($validator)->withInput();
		  
		}
		else
		{  
		  $current_password = Auth::User()->password;           
		  if(Hash::check($request_data['current-password'], $current_password))
		  { 
			 $user_id = Auth::User()->id;                       
			 $obj_user = User::find($user_id);
			 $obj_user->password = Hash::make($request_data['password']);;
			 $obj_user->save(); 
			$success = array('successMsg' => 'Password Changed Successfully ,Please Login again'); 

			Auth::Logout();
			 return Redirect('/login')->with($success);
		  }
		  else
		  {           
			$error = array('current-password' => 'Please enter correct current password'); 
			 return Redirect::back()->withErrors($error);
		  }
		}        
	  }
	  else
	  {
		return redirect()->to('SuperAdmin.change_password');
	  }    
	}
	
		public function NewChangeBranchPassword(Request $request)
	{  //die('feed');
	  if(Auth::Check())
	  {
		$request_data = $request->All();
		$validator = $this->admin_credential_rules($request_data);
		if($validator->fails())
		{
		   return Redirect::back()->withErrors($validator)->withInput();
		  
		}
		else
		{  
		  $current_password = Auth::User()->password;           
		  if(Hash::check($request_data['current-password'], $current_password))
		  { 
			 $user_id = Auth::User()->id;                       
			 $obj_user = User::find($user_id);
			 $obj_user->password = Hash::make($request_data['password']);;
			 $obj_user->save(); 
			$success = array('successMsg' => 'Password Changed Successfully ,Please Login again'); 

			Auth::Logout();
			 return Redirect('/login')->with($success);
		  }
		  else
		  {           
			$error = array('current-password' => 'Please enter correct current password'); 
			 return Redirect::back()->withErrors($error);
		  }
		}        
	  }
	  else
	  {
		return redirect()->to('SuperAdmin.change_password');
	  }    	
		  
		  
	}  
	
	public  function booking(){
		 $activeMenu = 'booking';
		
		$customer_id = Auth::user()->id;
		$Booking_detail = Booking::with('getbranch','getclient')->where('customer_id',$customer_id)->orderBy('current_date', 'desc')->orderBy('booking_time', 'desc')->paginate(10);
        //echo "<pre>";  print_r($Booking_detail); die;
        	   
		return view('customer/booking')->with(compact('Booking_detail','activeMenu'));
	}
	
	
	 public function status(Request $request , $id ,$stat )
     {    
	  
	    $input = $request->all();
		if($stat == 1){
		$status = 0;	
			
		}
		elseif($stat == 0){
			
		$status = 1;	
			
		}
		
		
		DB::table('booking')
             ->where('id', $id)
             ->update([
              'status' => $status
			 		]); 
		
		
		return response()->json(['is'=>'success'], $this-> successStatus); 
	}
	
	
	public  function postPond(Request $request){
		  $input = $request->all();
		  $id = $request->id;
		  $r =  DB::table('booking')->where('id', $id)->first();
		  $updatCheck = $r->open_close_status;
		  $current_date =  date('Y-m-d');
			
			if($updatCheck < 2){
			  
			  $count =$updatCheck+1;
			  $time = $request->post_pond_time;
		      $current_booking = Booking::find($id);
		      $appointment_date = $current_booking->booking_time;
		  
		
		$cenvertedTime = date('h:i:s a',strtotime( '+'.$time.' minutes', strtotime($appointment_date)));
	
		DB::table('booking')
             ->where('id', $id)
             ->update([
              'booking_time' => $cenvertedTime,
              'open_close_status' => $count,
			  'current_date' => $current_date
			 		]); 
		return redirect('customer/booking');
			 
		  }
		  else{
			
		  Session::flash('flash_message', 'you can postpond booking only two time');
          Session::flash('alert-class', 'alert-success');	
		  return redirect('customer/booking');  
		  }
		  
		
	}
	
	
	
	

  
	
	public function isVerified(Request $request) {
		// echo $passwod= Auth::user()->password;
			Auth::logout();
	  return redirect('/login')->with('successMsg','Thanks You Account Verified Successfully');
	}
	
}
